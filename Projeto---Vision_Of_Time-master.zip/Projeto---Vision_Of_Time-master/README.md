# PROJETO_PRÁTICO_DE_CONSTRUÇÃO_DE_SISTEMAS_COMPUTACIONAIS
Turma_42- UNIVERSIDADE NOVE DE JULHO 
Entregue em: 25/05/2022

------------------------------------------------------------------------------------------------------------------------------

FOI REALIZADO O DESENVOLVIMENTO DE UM APLICATIVO DE PREVISÃO DO TEMPO, ONDE VOCÊ PODE REALIZAR A CONSULTA DA PREVISÃO DO TEMPO DE QUALQUER ESTADO OU CIDADE BRASILEIRA.
SOBRETUDO VERIFICAR INFORMAÇÕES: TEMPERATURA ATUAL, TEMPERATURA MÁXIMA, TEMPERATURA MÍNIMA, PRESSÃO ATMOSFÉRICA, UMIDADE RELATIVA DO AR VISIBILIDADE DAS NUVENS.

------------------------------------------------------------------------------------------------------------------------------

**INTEGRANTES**\
42018089   Leonardo Oliveira Alves\
920101311  Marcos Vinicius Bueno da Silva\
920119682  Nicolas Batista Costa\
920126602  Rodrigo Freitas Barreto
